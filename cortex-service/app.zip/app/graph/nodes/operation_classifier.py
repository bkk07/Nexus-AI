from __future__ import annotations

from app.core.operations import OperationType
from app.core.execution_plan import ExecutionPlan
from app.graph.state import AgentState

def classify_operation(
    question: str,
) -> ExecutionPlan:
    """
    Convert a user's natural-language request into
    an execution plan.

    This is the first deterministic version.
    No LLM and no external API calls are used here.
    """

    text = question.lower().strip()

    plan = ExecutionPlan()

    # ============================================================
    # COUNT
    # ============================================================

    if (
        "how many" in text
        or "number of" in text
        or "count" in text
    ):
        plan.add_operation(
            OperationType.COUNT,
            "gmail",
            {
                "query": _extract_gmail_query(text),
            },
        )

        return plan

    # ============================================================
    # AGGREGATE
    # ============================================================

    if (
        "most" in text
        or "top" in text
        or "breakdown" in text
        or "group by" in text
    ):
        plan.add_operation(
            OperationType.AGGREGATE,
            "gmail",
            {
                "query": _extract_gmail_query(text),
            },
        )

        return plan

    # ============================================================
    # SUMMARIZE
    # ============================================================

    if (
        "summarize" in text
        or "summary" in text
        or "summarise" in text
    ):
        plan.add_operation(
            OperationType.SEARCH,
            "gmail",
            {
                "query": _extract_gmail_query(text),
                "top_k": 10,
            },
        )

        plan.add_operation(
            OperationType.FETCH,
            "gmail",
            {
                "source": "previous_operation",
            },
            depends_on=0,
        )

        plan.add_operation(
            OperationType.SUMMARIZE,
            "llm",
            {
                "source": "previous_operation",
            },
            depends_on=1,
        )

        return plan

    # ============================================================
    # EXTRACT
    # ============================================================

    if (
        "extract" in text
        or "find the phone" in text
        or "find the email address" in text
        or "find the url" in text
    ):
        plan.add_operation(
            OperationType.SEARCH,
            "gmail",
            {
                "query": _extract_gmail_query(text),
                "top_k": 10,
            },
        )

        plan.add_operation(
            OperationType.FETCH,
            "gmail",
            {
                "source": "previous_operation",
            },
            depends_on=0,
        )

        plan.add_operation(
            OperationType.EXTRACT,
            "gmail",
            {
                "source": "previous_operation",
            },
            depends_on=1,
        )

        return plan

    # ============================================================
    # CLASSIFY
    # ============================================================

    if (
        "classify" in text
        or "categorize" in text
        or "category" in text
        or "type of email" in text
    ):
        plan.add_operation(
            OperationType.SEARCH,
            "gmail",
            {
                "query": _extract_gmail_query(text),
                "top_k": 10,
            },
        )

        plan.add_operation(
            OperationType.CLASSIFY,
            "gmail",
            {
                "source": "previous_operation",
            },
            depends_on=0,
        )

        return plan

    # ============================================================
    # FILTER
    # ============================================================

    if (
        "only" in text
        or "filter" in text
        or "unread" in text
        or "starred" in text
    ):
        plan.add_operation(
            OperationType.SEARCH,
            "gmail",
            {
                "query": _extract_gmail_query(text),
                "top_k": 20,
            },
        )

        plan.add_operation(
            OperationType.FILTER,
            "gmail",
            {
                "source": "previous_operation",
            },
            depends_on=0,
        )

        return plan

    # ============================================================
    # FETCH
    # ============================================================

    if (
        "open" in text
        or "read" in text
        or "show me the full" in text
        or "full email" in text
    ):
        plan.add_operation(
            OperationType.SEARCH,
            "gmail",
            {
                "query": _extract_gmail_query(text),
                "top_k": 10,
            },
        )

        plan.add_operation(
            OperationType.FETCH,
            "gmail",
            {
                "source": "previous_operation",
            },
            depends_on=0,
        )

        return plan

    # ============================================================
    # SEARCH
    # ============================================================

    plan.add_operation(
        OperationType.SEARCH,
        "gmail",
        {
            "query": text,
            "top_k": 10,
        },
    )

    return plan


def _extract_gmail_query(
    text: str,
) -> str:
    """
    First deterministic version.

    We intentionally keep this simple.
    The Gmail query compiler can later translate
    richer natural-language constraints.
    """

    return text

def operation_classifier_node(
    state: AgentState,
) -> AgentState:
    """
    LangGraph node that converts the user's question
    into an ExecutionPlan and stores it in AgentState.
    """

    question = state.get("question", "").strip()

    if not question:
        return {
            **state,
            "operation_plan": None,
            "operation_results": {},
        }

    plan = classify_operation(question)

    return {
        **state,
        "operation_plan": plan,
        "operation_results": {},
    }