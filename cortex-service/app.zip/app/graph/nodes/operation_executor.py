from __future__ import annotations

from typing import Any

from app.core.operations import OperationType
from app.graph.state import AgentState
from app.connectors.gmail.connector import (
    build_default_gmail_connector,
)


async def operation_executor_node(
    state: AgentState,
) -> dict[str, Any]:
    """
    Execute operations from AgentState.operation_plan.

    This node dispatches operations to the appropriate
    connector/service.

    Currently supported Gmail operations:

        SEARCH
        FETCH
        COUNT
        FILTER
        CLASSIFY
        EXTRACT

    SUMMARIZE is intentionally not executed here.
    It will be handled by the LLM/post-processing layer.
    """

    print("\n--- [NODE] Operation Executor ---")

    plan = state.get("operation_plan")

    if plan is None or plan.is_empty():
        return {
            "operation_results": {},
        }

    gmail = build_default_gmail_connector()

    operation_results: dict[str, Any] = {}

    for index, operation in enumerate(plan.operations):

        operation_type = operation.operation_type

        print(
            f" -> Operation [{index}] "
            f"{operation_type.value} "
            f"connector={operation.connector}"
        )

        # ------------------------------------------------------
        # Gmail
        # ------------------------------------------------------

        if operation.connector == "gmail":

            # --------------------------------------------------
            # SEARCH
            # --------------------------------------------------

            if operation_type == OperationType.SEARCH:

                query = operation.parameters.get(
                    "query",
                    "",
                )

                top_k = operation.parameters.get(
                    "top_k",
                    10,
                )

                result = await gmail.search(
                    query=query,
                    top_k=top_k,
                )

                operation_results[
                    operation_type.value.lower()
                ] = result

            # --------------------------------------------------
            # FETCH
            # --------------------------------------------------

            elif operation_type == OperationType.FETCH:

                source = operation.parameters.get(
                    "source",
                )

                # For now FETCH expects the previous
                # SEARCH result.
                previous_result = None

                if (
                    source == "previous_operation"
                    and index > 0
                ):
                    previous_operation = (
                        plan.operations[index - 1]
                    )

                    previous_key = (
                        previous_operation
                        .operation_type
                        .value
                        .lower()
                    )

                    previous_result = (
                        operation_results.get(
                            previous_key
                        )
                    )

                if not previous_result:
                    operation_results[
                        operation_type.value.lower()
                    ] = []

                    continue

                fetched = []

                for email in previous_result:

                    message_id = email.get("id")

                    if not message_id:
                        continue

                    fetched_email = await gmail.fetch(
                        message_id
                    )

                    fetched.append(
                        fetched_email
                    )

                operation_results[
                    operation_type.value.lower()
                ] = fetched

            # --------------------------------------------------
            # COUNT
            # --------------------------------------------------

            elif operation_type == OperationType.COUNT:

                query = operation.parameters.get(
                    "query",
                    "",
                )

                count = await gmail.count(
                    query=query,
                )

                operation_results[
                    operation_type.value.lower()
                ] = count

            # --------------------------------------------------
            # FILTER
            # --------------------------------------------------

            elif operation_type == OperationType.FILTER:

                source = operation.parameters.get(
                    "source",
                )

                previous_result = None

                if (
                    source == "previous_operation"
                    and index > 0
                ):
                    previous_operation = (
                        plan.operations[index - 1]
                    )

                    previous_key = (
                        previous_operation
                        .operation_type
                        .value
                        .lower()
                    )

                    previous_result = (
                        operation_results.get(
                            previous_key
                        )
                    )

                if previous_result is None:
                    previous_result = []

                field = operation.parameters.get(
                    "field",
                    "subject",
                )

                operator = operation.parameters.get(
                    "operator",
                    "contains",
                )

                value = operation.parameters.get(
                    "value",
                    "",
                )

                filtered = gmail.filter_emails(
                    emails=previous_result,
                    field=field,
                    operator=operator,
                    value=value,
                )

                operation_results[
                    operation_type.value.lower()
                ] = filtered

            # --------------------------------------------------
            # CLASSIFY
            # --------------------------------------------------

            elif operation_type == OperationType.CLASSIFY:

                source = operation.parameters.get(
                    "source",
                )

                previous_result = None

                if (
                    source == "previous_operation"
                    and index > 0
                ):
                    previous_operation = (
                        plan.operations[index - 1]
                    )

                    previous_key = (
                        previous_operation
                        .operation_type
                        .value
                        .lower()
                    )

                    previous_result = (
                        operation_results.get(
                            previous_key
                        )
                    )

                if previous_result is None:
                    previous_result = []

                classified = gmail.classify_emails(
                    previous_result
                )

                operation_results[
                    operation_type.value.lower()
                ] = classified

            # --------------------------------------------------
            # EXTRACT
            # --------------------------------------------------

            elif operation_type == OperationType.EXTRACT:

                source = operation.parameters.get(
                    "source",
                )

                previous_result = None

                if (
                    source == "previous_operation"
                    and index > 0
                ):
                    previous_operation = (
                        plan.operations[index - 1]
                    )

                    previous_key = (
                        previous_operation
                        .operation_type
                        .value
                        .lower()
                    )

                    previous_result = (
                        operation_results.get(
                            previous_key
                        )
                    )

                if previous_result is None:
                    previous_result = []

                fields = operation.parameters.get(
                    "fields",
                    [
                        "emails",
                        "urls",
                        "phones",
                    ],
                )

                extracted = []

                for email in previous_result:

                    extracted.append(
                        {
                            "id": email.get("id"),
                            "extracted": (
                                gmail.extract_information(
                                    email,
                                    fields,
                                )
                            ),
                        }
                    )

                operation_results[
                    operation_type.value.lower()
                ] = extracted

            # --------------------------------------------------
            # SUMMARIZE
            # --------------------------------------------------

            elif operation_type == OperationType.SUMMARIZE:

                operation_results[
                    operation_type.value.lower()
                ] = {
                    "status": "PENDING_LLM",
                    "source": operation.parameters.get(
                        "source"
                    ),
                }

            else:

                operation_results[
                    operation_type.value.lower()
                ] = {
                    "status": "UNSUPPORTED_OPERATION",
                    "operation": operation_type.value,
                }

        else:

            operation_results[
                operation_type.value.lower()
            ] = {
                "status": "UNSUPPORTED_CONNECTOR",
                "connector": operation.connector,
            }

    return {
        "operation_results": operation_results,
    }